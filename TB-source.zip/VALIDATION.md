# Validation — 2026-11-11

## Passed

- JavaScript syntax checks: engine.js, ui.js, learning.js.
- 81 deterministic clinical and content checks (`node tests/clinical.test.cjs`; v1.1 run under JavaScriptCore with a small require shim).
- All 12 demonstrations have expected diagnostic categories and teaching notes.
- Unknown data and unresolved contraindications do not automatically qualify a patient for the 17-week regimen.
- IGRA alone does not diagnose active disease; conflicting active/latent inputs block preventive treatment routing.
- AFB/MTB mismatch, prior-treated NAAT positivity, H resistance and R resistance route separately.
- HD Z/E intervals, PD individualization, no Z dose when Z unavailable, pediatric dose-table exclusion and extreme adult weight exclusion.
- Urgent signs, ALT thresholds, vision alerts and persistent culture positivity prompt reassessment.
- 20 questions have four choices, a valid answer, explanations and source references; 10 basic and 10 advanced.
- Mindmap has 10 main branches and more than 60 explanatory leaves.
- Uploaded index.html blob matched the local artifact for the first deployment; the final artifact is independently hash-checked against repository content.

## v1.1 debugging pass (2026-11-11)

- Unknown infection site no longer routes as extrapulmonary (next steps, DS duration, DR lines).
- LTBI / no-active pathways no longer request diagnostic cultures or DST; they show contact-DST, baseline-liver and retest steps.
- "Excluded + IGRA indeterminate/unknown" is no longer described as a negative infection test.
- Month-4 culture positivity overrides the 9-month extension and shows a suspected-failure plan; blocks 17-week eligibility.
- ALT stop threshold blocks 17-week eligibility; ALT and vision alerts are written into the treatment plan (and print summary).
- Treatment title no longer says "標準6個月療程" when the duration is extended; CNS duration kept when Z is unavailable; miliary and HIV prompts added.
- UI: invalid number input clears the value instead of silently keeping the previous one; demo/reset only touch form fields; print summary expands collapsed sections; sticky live status bar below 1100 px; 16 px mobile inputs (no iOS zoom); quiz moves focus to the explanation.
- Live browser check (localhost) of all 12 demos, quiz, mind map and invalid input: no console errors.

## v1.2 content expansion (2026-11-11)

- 6 new demos (INH-resistant, pregnancy, child lymph node, prior-treated NAAT+, pleural clinical diagnosis, PD) with pathway-specific tests.
- 40 questions (20 basic, 20 advanced, unique stems, valid refs); quiz counts and per-level scores computed from the data; jump menu.
- Mind map: 15 branches, >100 leaves, keyword search. Browser-checked on desktop and 375 px (no overflow, no console errors).

## v1.3 layout consolidation (2026-11-11)

- One top tab bar (assessment, cases, quiz, mind map, sources) replaces header buttons, sidebar buttons and modal dialogs; hash deep links.
- Cases grouped as cards (basic 8 / complex 4 / advanced 6); quiz ordered basic 1–20, advanced 21–40 with progress bar; mind map's 15 branches grouped into 4 step-aligned blocks, each placed exactly once (tested).
- Browser-checked at desktop and 375 px: all five views without horizontal overflow, no console errors.

## Verification limit

The environment blocked a local HTTP server and file-URL browser preview. The browser also denied access to the github.io origin, so desktop/mobile rendering and live interaction could not be directly verified in this session. No live-browser test pass is claimed. GitHub Pages deployment is checked through the repository's deployment status and Pages settings.

This is clinical decision support with conservative gates, not a validated mortality score or autonomous prescription system. Specialist review is required before clinical adoption.
