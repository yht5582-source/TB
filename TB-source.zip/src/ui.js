const steps=['病人與警訊','病原與診斷','治療選擇','預後與追蹤'];
const state={};let current=0;
const fields={};
const refs=[
 ['WHO 2025 診斷指引','https://www.who.int/publications/i/item/9789240107984','感染、疾病與抗藥性檢測'],
 ['WHO 2026 治療指引，第2版','https://www.who.int/publications/i/item/9789240125124','2026-09-25；成人、兒童及抗藥性結核'],
 ['WHO 2026 抗藥方案更新','https://www.who.int/news/item/30-09-2026-who-updates-guidelines-on-drug-resistant-tuberculosis-and-palliative-care','BPaLM、BPaL、重症pre-XDR之BPaLC'],
 ['ATS／CDC／ERS／IDSA 2025','https://www.idsociety.org/practice-guideline/treatment-of-drug-susceptible-tb/treatment-of-drug-resistant-and-drug-susceptible-tb-2025-update/','成人與兒童短療程'],
 ['ATS／CDC／IDSA 診斷指引','https://www.idsociety.org/practice-guideline/diagnosis-of-tb-in-adults-and-children/','核酸陰性限制、肺外採檢'],
 ['ATS／CDC／IDSA 藥敏感結核','https://www.idsociety.org/practice-guideline/treatment-of-drug-susceptible-tb/','劑量、腎病調整、追蹤與肝毒性'],
 ['CDC 四個月療程適用條件','https://www.cdc.gov/mmwr/volumes/71/wr/mm7108a1.htm','8週＋9週；禁忌與專家諮詢情境'],
 ['CDC 潛伏感染治療','https://www.cdc.gov/tb/hcp/treatment/latent-tuberculosis-infection.html','3HP、4R、3HR、6H／9H'],
 ['台灣疾管署：重要指引及教材','https://www.cdc.gov.tw/Category/MPage/YpPM4PxFx3b_6FKuMDYjew','病例定義、診治、公費、通報與隔離；須核對當地現行規範'],
 ['CDC 臨床及實驗室診斷','https://www.cdc.gov/tb/hcp/testing-diagnosis/clinical-and-laboratory-diagnosis.html','痰塗片、核酸、培養及藥敏'],
 ['WHO 藥敏感結核及特殊族群操作手冊','https://www.who.int/publications/i/item/9789240108141','2025；腎功能不全與透析劑量'],
 ['WHO 治療與照護整合指引（2025）','https://www.who.int/publications/i/item/9789240107243','含INH抗藥、R敏感方案；未更新之建議仍有效']
];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function field(k,label,type,options,hint=''){
 fields[k]=label;if(!(k in state))state[k]=type==='number'?'':'unknown';
 if(type==='number')return `<label class="field" for="${k}"><span>${label}</span><input id="${k}" name="${k}" type="number" step="any" ${k==='age'?'min="0" max="120"':k==='weight'?'min="1" max="300"':k==='crcl'?'min="0" max="250"':'min="0"'} placeholder="尚未填入">${hint?`<small>${hint}</small>`:''}</label>`;
 return `<label class="field" for="${k}"><span>${label}</span><select id="${k}" name="${k}"><option value="unknown">尚未確認</option>${options.map(o=>`<option value="${o[0]}">${o[1]}</option>`).join('')}</select>${hint?`<small>${hint}</small>`:''}</label>`;
}
const yn=(k,l,h='')=>field(k,l,'select',[['yes','是'],['no','否']],h);
const num=(k,l,h='')=>field(k,l,'number',null,h);
const sel=(k,l,o,h='')=>field(k,l,'select',o,h);
const test=[['positive','陽性'],['negative','陰性'],['pending','已採檢，待報告']];
const dst=[['sensitive','敏感'],['resistant','抗藥'],['pending','待報告']];
const heading=(n,t)=>`<div class="section-title"><span>${n}</span><h2>${t}</h2></div>`;
const panels=[
`${heading('01','病人與警訊')}<p class="lead">先辨識急症，再建立診斷。</p><p class="note">僅填去識別化臨床資料。本頁不傳送、不自動儲存病人資料；重新整理即清除。</p><div class="grid">${num('age','年齡（歲）','兒童可填小數，例如0.5歲。')}${num('weight','體重（kg）')}${num('crcl','CrCl（mL/min）','用於藥物調整；非標準化eGFR，不可直接視為相同。')}${sel('site','感染部位',[['pulmonary','肺／喉部'],['pleural','胸膜'],['node','淋巴結'],['cns','腦膜／中樞神經'],['bone','骨關節／脊椎'],['other','其他肺外部位']])}${yn('hd','血液透析')}${yn('pd','腹膜透析')}</div><details open><summary>急症警訊</summary><div class="grid">${yn('resp','呼吸衰竭／嚴重低氧')}${yn('shock','休克／血流動力不穩')}${yn('hemoptysis','大量咳血／呼吸道威脅')}${yn('neuro','意識改變／新神經缺損')}</div></details><details open><summary>症狀、接觸史與共病</summary><div class="grid">${yn('cough','持續咳嗽／咳痰')}${yn('fever','持續發燒')}${yn('night','夜間盜汗')}${yn('loss','不明體重減輕')}${yn('contact','結核接觸史')}${yn('past','曾接受活動性結核治療')}${yn('dm','糖尿病')}${yn('immune','免疫抑制／免疫治療')}${yn('malnutrition','營養不良')}${sel('hiv','HIV狀態',[['yes','陽性'],['no','陰性']])}${num('cd4','CD4（cells/μL）','HIV陽性者填入。')}${yn('art','ART已確認與候選處方相容')}</div></details>`,
`${heading('02','病原與診斷')}<p class="lead">把每項檢驗放回臨床情境。</p><div class="grid">${sel('image','胸部影像',[['normal','無支持活動性病灶'],['suggestive','疑似活動性病灶'],['cavity','空洞病灶'],['miliary','粟粒型／播散疑慮']])}${sel('smear','AFB塗片',test)}${sel('naat','MTB核酸',test,'例如Xpert MTB/RIF／Ultra。')}${sel('culture','MTB培養',test,'陽性指已鑑定為MTB，不僅是分枝桿菌生長。')}${sel('igra','IGRA／TST感染檢測',[['positive','支持結核感染'],['negative','陰性'],['indeterminate','無法判讀']])}${sel('severity','疾病嚴重度',[['nonsevere','經專科確認非重症'],['severe','重症／廣泛病灶']])}</div><details open><summary>醫師綜合判定</summary><div class="grid">${yn('clinical','醫師已作臨床活動性結核診斷','症狀、影像／病理及替代診斷評估完成後判定；不是只憑IGRA。')}${yn('excluded','已完成評估並排除活動性結核','進入潛伏感染治療前必須完成；有症狀／病灶需先釐清。')}${yn('child','兒科已確認符合非重症短療程定義','限少菌量、非空洞、無粟粒型，或符合指引之淋巴結／非複雜胸膜病灶。')}</div></details><div id="diagnosis-output"></div><details><summary>檢驗判讀與採檢原則</summary><ul><li>疑似肺結核：塗片、MTB核酸、培養及藥敏並行；依當地流程採足量痰。CDC建議三份，間隔8–24小時，至少一份清晨痰。</li><li>AFB陽性仍可能為NTM；MTB核酸有助鑑別，但保留培養與藥敏。</li><li>塗片陰性、核酸陰性或培養陰性，均不可單獨排除結核。</li><li>肺外結核需病灶取材；ADA、肉芽腫或乾酪性壞死是支持證據，須排除其他感染及疾病。</li><li>IGRA／TST不能區分活動性與潛伏感染，亦不適合追蹤治癒。</li></ul><p class="source">依據：WHO診斷、ATS診斷、CDC臨床診斷；見指引來源。</p></details>`,
`${heading('03','治療選擇')}<p class="lead">先看藥敏，再審查療程資格。</p><div class="grid">${sel('rif','Rifampicin（R）藥敏',dst)}${sel('inh','Isoniazid（H）藥敏',dst)}${sel('pza','Pyrazinamide（Z）藥敏',dst)}${sel('fq','Fluoroquinolone（FQ）藥敏',dst)}${yn('pzaUse','可使用Pyrazinamide')}${yn('preg','目前懷孕','不適用者選否。')}${yn('breast','目前哺乳','不適用者選否。')}${yn('qt','QT延長／QT延長藥物風險')}${yn('ddi','存在尚未解決的重大交互作用','包含rifamycin與免疫抑制劑、抗凝劑或ART。')}${yn('liver','嚴重肝病／顯著基線肝功能異常')}${yn('prior','近期結核用藥／FQ暴露疑慮','包括近期超過5劑相關用藥；短療程需專家諮詢。')}${yn('core','二線核心藥既往暴露＞1個月／抗藥疑慮','如bedaquiline、pretomanid、linezolid；未知不等於無。')}</div><div id="treatment-output"></div>`,
`${heading('04','預後與追蹤')}<p class="lead">用治療反應調整風險與下一步。</p><div class="grid">${sel('month2','治療滿2個月痰培養',[['notyet','尚未到時點'],['negative','陰性／已轉陰'],['positive','仍陽性'],['pending','待報告']])}${sel('month4','治療滿4個月後痰培養',[['notyet','尚未到時點'],['negative','陰性'],['positive','仍陽性'],['pending','待報告']])}${sel('adherence','服藥完成情形',[['good','規律服藥'],['poor','漏藥／中斷']])}${num('alt','目前ALT／正常上限（倍）','例如ALT 150、ULN 40，填3.75。')}${yn('hepatitis','肝炎症狀／黃疸')}${yn('vision','新視力下降／色覺異常')}</div><div id="prognosis-output"></div>`
];
document.querySelector('#panels').innerHTML=panels.map((p,i)=>`<section id="step-${i}" ${i?'hidden':''}>${p}</section>`).join('');
document.querySelector('#steps').innerHTML=steps.map((x,i)=>`<button data-step="${i}" class="step ${i===0?'active':''}"><b>${i+1}</b><span>${x}</span></button>`).join('');
const list=a=>`<ul>${a.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`;
function resultHTML(r){
 let html=`<div class="result"><p class="label">療程建議</p><h3>${esc(r.treatment.title)}</h3><p class="duration">${esc(r.treatment.duration)}</p>${list(r.treatment.lines)}</div>`;
 if(r.treatment.kind==='ds')html+=`<details ${r.treatment.short?'open':''}><summary>成人四個月方案資格：${r.treatment.short?'符合候選篩選':'尚未符合／需補資料'}</summary>${r.shortReasons.length?list(r.shortReasons):'<p>候選方案H＋rifapentine＋Z＋moxifloxacin，8週後改H＋rifapentine＋moxifloxacin再9週。須確認藥物供應、當地規範及醫師最終審查。</p>'}<p>有CKD、近期暴露或肺外病灶者，本工具採保守篩選並轉專家評估；不代表絕對禁忌。兒童4個月方案為另一套資格。</p></details>`;
 if(r.dose.length)html+=`<h3>成人一般標準方案：體重換算</h3><p class="note">僅供一般體型成人處方核對；非電子處方。肥胖／極低體重需確認計量體重及TDM。依可用錠劑調整前需藥師確認。短療程／二線藥請另循專責處方；Z不可用者勿照表給Z。</p><div class="table-wrap"><table><thead><tr><th>藥物</th><th>參考劑量</th><th>監測</th></tr></thead><tbody>${r.dose.map(d=>`<tr>${d.map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
 if(r.active&&r.treatment.kind==='ds'&&!r.dose.length)html+='<p class="callout">請補年齡、體重、CrCl與透析狀態後顯示成人劑量。未滿18歲或體重超出本表30–90kg範圍者，需專科／藥師個別化，不套用本成人表。</p>';
 if(r.renal)html+='<p class="callout">腎臟重點：H／R通常維持每日劑量；嚴重腎功能不全時Z／E延長間隔。HD日透析後給藥；PD不能直接照搬HD表，需個別化及必要時TDM。固定複方可能不適合不同給藥間隔。</p>';
 html+='<p class="source">依據：WHO 2026／2025、ATS 2025／2016、CDC 4個月資格及LTBI指引。國際推薦不等同台灣公費核准；開方前核對疾管署現行規範。</p>';return html;
}
function render(){
 const r=TB.assess(state);
 document.querySelector('#diagnosis-output').innerHTML=`<div class="result"><p class="label">診斷定位</p><h3>${esc(r.dx)}</h3><p>${esc(r.detail)}</p></div><h3>下一步檢查</h3>${list(r.next.length?r.next:['檢體及藥敏已填寫；仍須核對報告、日期與採檢部位。'])}`;
 document.querySelector('#treatment-output').innerHTML=resultHTML(r);
 let urgent=r.urgent.length||r.liverAlert||state.vision==='yes';
 document.querySelector('#alerts').innerHTML=urgent?`<div class="alert" role="alert"><strong>需立即處理</strong><p>${r.urgent.length?'目前有急症警訊：先急診／住院、穩定病況及感控。 ':''}${r.liverAlert?'ALT達肝毒性停藥評估門檻。 ':''}${state.vision==='yes'?'視力／色覺異常，立即停EMB並轉眼科。':''}</p></div>`:'';
 document.querySelector('#rail-dx').textContent=r.dx;
 document.querySelector('#rail-next').innerHTML=list(r.next.length?r.next.slice(0,3):['目前無待補採檢；持續核對報告與治療反應。']);
 document.querySelector('#rail-missing').innerHTML=r.missing.length?`<p>尚缺：${esc(r.missing.join('、'))}</p>`:'<p>基本欄位已填；請繼續核對檢驗及療程限制。</p>';
 document.querySelector('#rail-rx').innerHTML=`<b>${esc(r.treatment.title)}</b><br>${esc(r.treatment.duration)}`;
 document.querySelector('#mini-status').innerHTML=`<span class="mini-dx">${esc(r.dx)}</span><span class="mini-rx">${esc(r.treatment.duration)}</span>${urgent?'<span class="mini-alert">⚠ 需立即處理</span>':''}`;
 let label=r.urgent.length?'有急症，優先穩定病況':state.month4==='positive'?'疑治療失敗，優先重新評估':!r.active?'尚無法判斷活動性結核治療預後':r.risk.length?'有需密切追蹤的風險因素':'已填資料未見明顯不利因素';
 document.querySelector('#prognosis-output').innerHTML=`<div class="result"><p class="label">預後定位</p><h3>${label}</h3><p>此為指引風險因素整理，並非經驗證的總分或個人死亡率模型。資料不完整時，不能解讀為低風險。</p></div><h3>目前辨識的因素</h3>${list(r.risk.length?r.risk:['尚未辨識已填資料中的不利因素；仍應完成完整評估。'])}<h3>建議行動</h3>${list(r.actions.length?r.actions:['依療程追蹤症狀、體重、服藥與培養反應，及早處理副作用。'])}<h3>追蹤時程</h3><div class="timeline"><p><b>治療前</b>核對菌種／藥敏、CBC、肝腎功能、HIV、體重及交互作用；EMB檢查視力／色覺。</p><p><b>每月</b>症狀、體重與劑量、服藥支持、副作用；肺結核痰塗片／培養追蹤至連續培養陰性。肝功能依基線風險及症狀安排。</p><p><b>第2個月</b>核對培養轉陰；標準6個月方案若初始空洞＋仍培養陽性，通常延至9個月。17週方案反應不佳者應重新評估，不能直接套用9個月規則。</p><p><b>第4個月後</b>培養仍陽性，評估治療失敗、重做藥敏、依專家重訂處方。</p><p><b>療程結束與之後</b>評估症狀、影像、殘餘肺功能障礙；高復發風險者安排追蹤。新咳嗽、發燒或體重下降應重新採檢。</p></div><p class="source">依據：ATS／CDC／IDSA藥敏感結核指引、CDC 17週方案。有效且完整治療下，多數藥敏感結核可治癒；此描述不是個人治癒保證。</p>`;
}
function go(i){current=i;document.querySelectorAll('#panels>section').forEach((x,n)=>x.hidden=n!==i);document.querySelectorAll('.step').forEach((x,n)=>{x.classList.toggle('active',n===i);x.setAttribute('aria-current',n===i?'step':'false')});document.querySelector('#prev').hidden=i===0;document.querySelector('#next').hidden=i===3;document.querySelector('#next').textContent=`下一步：${steps[i+1]||''} →`;document.querySelector('#position').textContent=`${i+1} / 4`;window.scrollTo({top:0,behavior:'smooth'});}
document.querySelectorAll('#panels [name]').forEach(el=>{el.value=state[el.name];el.addEventListener('change',()=>{if(el.type==='number'&&!el.checkValidity()){el.reportValidity();state[el.name]='';render();return;}state[el.name]=el.value;render()});el.addEventListener('input',()=>{if(el.type==='number'){state[el.name]=el.checkValidity()?el.value:'';render()}})});
document.querySelector('#steps').onclick=e=>{const b=e.target.closest('[data-step]');if(b)go(Number(b.dataset.step))};
document.querySelector('#next').onclick=()=>{const inputs=document.querySelectorAll(`#step-${current} input`);if([...inputs].every(e=>e.reportValidity()))go(Math.min(3,current+1))};
document.querySelector('#prev').onclick=()=>go(Math.max(0,current-1));
const common={age:'45',weight:'60',crcl:'90',site:'pulmonary',hd:'no',pd:'no',resp:'no',shock:'no',hemoptysis:'no',neuro:'no',cough:'yes',fever:'yes',night:'no',loss:'no',contact:'no',past:'no',dm:'no',immune:'no',malnutrition:'no',hiv:'no',cd4:'',art:'unknown',image:'suggestive',smear:'positive',naat:'positive',culture:'positive',igra:'positive',severity:'nonsevere',clinical:'no',excluded:'no',child:'no',rif:'sensitive',inh:'sensitive',pza:'sensitive',fq:'sensitive',pzaUse:'yes',preg:'no',breast:'no',qt:'no',ddi:'no',liver:'no',prior:'no',core:'no',month2:'notyet',month4:'notyet',adherence:'good',alt:'1',hepatitis:'no',vision:'no'};
const caseNotes=[
'45歲60kg，MTB病原與H/R/Z/FQ敏感均確認，無重要限制。觀察：6個月標準療程及17週候選，兩者可討論。',
'72歲55kg、HD、CrCl5、DM。觀察：Z/E間隔、透析後給藥與B6；不自動選成人4個月。',
'初始空洞且滿2個月培養仍陽性。觀察：標準方案通常延至9個月，並檢查服藥與藥敏。',
'R與H抗藥、FQ敏感。觀察：RR/MDR專責評估與BPaLM候選；不自動開二線處方。',
'R/H/FQ抗藥、重症肺部病灶。觀察：WHO2026重症pre-XDR的BPaLC候選及毒性監測。',
'接觸史、感染檢測陽性、無症狀及影像病灶、活動性結核已排除。觀察：LTBI路徑與感染源藥敏。',
'AFB陽性、MTB核酸陰性、培養未回。觀察：NTM鑑別、檢體問題及培養，不把AFB直接當MTB。',
'腦膜結核且新神經缺損。觀察：急症、專科住院、延長療程與類固醇。',
'61歲腎移植、免疫抑制、CrCl35，存在尚未解決的重大交互作用。觀察：rifampicin與tacrolimus/cyclosporine濃度、移植物風險及專科共同調整。',
'79歲48kg、HD、DM、營養不良，ALT6×ULN並有肝炎症狀，出現視力改變。觀察：立即處理肝毒性、停EMB並轉眼科，不能只完成例行追蹤。',
'HIV陽性CD4 45、ART相容性未完成、粟粒型。觀察：播散及CNS評估、ART時機與交互作用需感染專科整合，不能自動用17週方案。',
'58歲DM、空洞、2月及4月後培養仍陽性且漏藥。觀察：疑治療失敗、重做藥敏、都治支持及吸收評估；不可只加單藥。',
'40歲，MTB確認，H抗藥、R與FQ敏感。觀察：改走6個月R＋E＋Z＋levofloxacin（6(H)REZ-Lfx）候選，不可沿用2HRZE／4HR；腎功能不全時Z／E／levofloxacin需調整。',
'29歲懷孕中、52kg，藥敏感肺結核。觀察：及時治療不延後至產後，並補B6；17週rifapentine-moxifloxacin方案及3HP不適用，與產科共同追蹤。',
'6歲20kg，頸部淋巴結結核，核酸陽性、影像無空洞或粟粒型，兒科確認非重症。觀察：可評估兒童4個月2HRZ(E)／2HR；成人劑量表與17週方案均不適用。',
'曾完成結核治療，再次咳嗽，核酸陽性但培養未回、塗片陰性。觀察：殘留核酸與真正復發需區分，追蹤培養、比對舊影像，不直接以核酸宣告復發。',
'38歲，單側肋膜積液，塗片與核酸陰性、培養未回；醫師依淋巴球為主滲出液及高ADA作臨床診斷。觀察：肺外推定藥敏感療程、胸膜切片提高培養率，並持續追蹤藥敏。',
'55歲62kg，腹膜透析、CrCl8、DM。觀察：PD不能照搬HD的每週3次表，Z／E需個別化及TDM；DM與CKD須補B6，17週方案需專家評估。'
];
const demos=[
 ['一般肺結核／4個月候選',{}],
 ['血液透析／劑量調整',{age:'72',crcl:'5',hd:'yes',dm:'yes',weight:'55'}],
 ['空洞＋2個月培養未轉陰',{image:'cavity',month2:'positive'}],
 ['R抗藥、FQ敏感',{rif:'resistant',inh:'resistant'}],
 ['重症pre-XDR',{rif:'resistant',inh:'resistant',fq:'resistant',severity:'severe',image:'cavity'}],
 ['潛伏感染',{cough:'no',fever:'no',image:'normal',smear:'negative',naat:'negative',culture:'negative',excluded:'yes',contact:'yes'}],
 ['AFB陽性／MTB核酸陰性',{naat:'negative',culture:'pending',rif:'unknown',inh:'unknown',pza:'unknown',fq:'unknown'}],
 ['腦膜結核／急症',{site:'cns',neuro:'yes',smear:'negative',image:'normal',severity:'severe'}],
 ['複雜：腎移植／rifampicin交互作用',{age:'61',crcl:'35',immune:'yes',ddi:'yes',past:'yes',prior:'yes'}],
 ['複雜：高齡HD／肝毒性及視力警訊',{age:'79',weight:'48',crcl:'4',hd:'yes',dm:'yes',malnutrition:'yes',alt:'6',hepatitis:'yes',vision:'yes'}],
 ['複雜：HIV／低CD4／播散疑慮',{age:'36',hiv:'yes',cd4:'45',art:'no',image:'miliary',immune:'yes',severity:'severe'}],
 ['複雜：第4個月培養陽性／漏藥',{age:'58',image:'cavity',month2:'positive',month4:'positive',adherence:'poor',dm:'yes',prior:'yes',pza:'unknown',fq:'unknown'}],
 ['進階：INH抗藥、R敏感',{age:'40',weight:'64',inh:'resistant'}],
 ['進階：懷孕肺結核',{age:'29',weight:'52',preg:'yes'}],
 ['進階：兒童淋巴結結核／非重症',{age:'6',weight:'20',site:'node',cough:'no',fever:'yes',image:'normal',smear:'negative',naat:'positive',culture:'pending',child:'yes',pza:'pending',fq:'pending'}],
 ['進階：曾治療者核酸陽性',{age:'66',weight:'50',past:'yes',smear:'negative',naat:'positive',culture:'pending',inh:'pending',pza:'pending',fq:'pending'}],
 ['進階：胸膜結核／臨床診斷',{age:'38',weight:'58',site:'pleural',cough:'no',image:'suggestive',smear:'negative',naat:'negative',culture:'pending',clinical:'yes',rif:'pending',inh:'pending',pza:'pending',fq:'pending'}],
 ['進階：腹膜透析／劑量個別化',{age:'55',weight:'62',crcl:'8',pd:'yes',dm:'yes'}]
];
document.querySelector('#cases').innerHTML=demos.map((d,i)=>`<button data-case="${i}"><span>${String(i+1).padStart(2,'0')}</span>${d[0]} →</button>`).join('');
function apply(s){for(const k of Object.keys(state))state[k]=s[k]??(document.getElementById(k)?.type==='number'?'':'unknown');document.querySelectorAll('#panels [name]').forEach(el=>el.value=state[el.name]);render();}
document.querySelector('#cases').onclick=e=>{const b=e.target.closest('[data-case]');if(!b)return;apply({...common,...demos[Number(b.dataset.case)][1]});document.querySelector('#case-dialog').close();document.querySelector('#demo-name').textContent='示範中：'+demos[Number(b.dataset.case)][0];document.querySelector('#case-teaching').hidden=false;document.querySelector('#case-teaching').textContent=caseNotes[Number(b.dataset.case)];go(0)};
document.querySelector('#demo').onclick=()=>document.querySelector('#case-dialog').showModal();
document.querySelector('#case-close').onclick=()=>document.querySelector('#case-dialog').close();
document.querySelector('#sources-btn').onclick=()=>document.querySelector('#sources-dialog').showModal();
document.querySelector('#sources-close').onclick=()=>document.querySelector('#sources-dialog').close();
document.querySelector('#sources').innerHTML=refs.map((r,i)=>`<li><a href="${r[1]}" target="_blank" rel="noopener">${esc(r[0])} ↗</a><p>${esc(r[2])}</p></li>`).join('');
document.querySelector('#reset').onclick=()=>document.querySelector('#reset-dialog').showModal();
document.querySelector('#reset-cancel').onclick=()=>document.querySelector('#reset-dialog').close();
document.querySelector('#reset-confirm').onclick=()=>{apply({});document.querySelector('#demo-name').textContent='';document.querySelector('#case-teaching').hidden=true;document.querySelector('#reset-dialog').close();go(0)};
document.querySelector('#print').onclick=()=>{const r=TB.assess(state);document.querySelector('#print-summary').innerHTML=`<h1>結核病臨床導航｜評估摘要</h1><p>產生日期：${new Date().toLocaleDateString('zh-TW')}｜指引查核2026-11-10</p><h2>${esc(r.dx)}</h2><p>${esc(r.detail)}</p><h2>填入資料</h2><div class="table-wrap"><table>${Object.keys(state).filter(k=>state[k]!==''&&state[k]!=='unknown').map(k=>{let el=document.getElementById(k);return `<tr><th>${esc(fields[k])}</th><td>${esc(el?.selectedOptions?el.selectedOptions[0].text:state[k])}</td></tr>`}).join('')}</table></div>${resultHTML(r)}<h2>預後及追蹤</h2>${list(r.risk)}${list(r.actions)}<p>臨床決策輔助，需由醫師確認；非驗證的死亡率模型。國際方案須核對台灣現行公費規範。</p><h2>指引來源</h2>${refs.map(r=>`<p>${esc(r[0])}<br>${esc(r[1])}</p>`).join('')}`;document.querySelectorAll('#print-summary details').forEach(d=>d.open=true);window.print()};
render();go(0);
