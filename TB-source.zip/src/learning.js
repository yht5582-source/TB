const questions=[
{level:'基礎',q:'IGRA陽性，最正確的解讀是？',o:['已確診活動性肺結核','支持曾感染結核菌，仍需排除活動性疾病','可以直接判定具有傳染性','可用IGRA數值追蹤治癒'],a:1,e:'IGRA檢測免疫反應，不能區分潛伏與活動性；需結合症狀、影像及必要的病原檢查。',ref:4},
{level:'基礎',q:'AFB塗片陽性是否代表MTB已確診？',o:['是，抗酸菌都是結核菌','是，可省略培養','否，仍可能NTM，需MTB核酸及菌種鑑定','否，必定是假陽性'],a:2,e:'塗片看見抗酸菌，無法直接區分MTB與NTM；核酸、培養與菌種鑑定仍有必要。',ref:9},
{level:'基礎',q:'高度懷疑肺結核，但初次MTB核酸陰性，應如何處理？',o:['立即完全排除結核','只做IGRA就能排除','不需再採檢','持續臨床評估，取得適當檢體及培養'],a:3,e:'少菌量、檢體品質或肺外病灶可能造成陰性。高臨床懷疑度下，不能單靠陰性核酸排除。',ref:4},
{level:'基礎',q:'一般藥敏感成人肺結核的標準6個月方案為何？',o:['2HRZE／4HR','6H單藥','2HR／4ZE','4HRZE／2Z'],a:0,e:'前2個月H/R/Z/E，後4個月H/R；需足量、規律治療及藥敏確認。',ref:5},
{level:'基礎',q:'下列何者是成人17週rifapentine-moxifloxacin候選方案的必要基本條件？',o:['任何年齡、任何體重','≥12歲且≥40kg的合適藥敏感肺結核','只有IGRA陽性即可','可任意包含大多數肺外結核'],a:1,e:'另需確認藥敏、懷孕哺乳、QT、交互作用與特殊族群限制；不是只看年齡體重。',ref:6},
{level:'基礎',q:'使用INH且有CKD或糖尿病時，通常應考慮加用何者？',o:['Vitamin K','葉酸作為唯一神經保護藥','Pyridoxine（B6）25–50mg/day','常規高劑量類固醇'],a:2,e:'腎病與糖尿病屬周邊神經病變高風險，通常合併B6；不應無限加大B6劑量。',ref:5},
{level:'基礎',q:'使用EMB後出現新視力下降及色覺異常，應？',o:['等下月回診','增加EMB','只補充維他命並繼續原量','立即停EMB並由眼科與結核團隊評估'],a:3,e:'EMB相關視神經毒性可能造成永久傷害，應立即處理，並重新規劃有效多藥方案。',ref:5},
{level:'基礎',q:'開始LTBI治療前，最重要的必要步驟是？',o:['排除活動性結核','先試單藥看症狀是否改善','只核對BCG接種史','不需要任何影像或症狀評估'],a:0,e:'活動性結核若被誤當潛伏感染，以單藥治療可能導致不足治療及抗藥性。',ref:7},
{level:'基礎',q:'肺外結核病灶採檢的合理作法為何？',o:['只驗IGRA即可','依部位送病理、培養及適用核酸，並評估陰性檢驗限制','肉芽腫一律等於MTB','ADA正常就可排除所有肺外結核'],a:1,e:'肺外結核往往少菌量，核酸陰性不能排除；病理及ADA提供支持，但須結合病原與鑑別診斷。',ref:4},
{level:'基礎',q:'下列何者最適合追蹤肺結核的病原學治療反應？',o:['每月重驗IGRA','只看血沉','痰培養及臨床反應，並在重要時點核對轉陰','只看核酸是否持續陽性'],a:2,e:'核酸可殘留死菌訊號；培養有助判斷活菌及治療反應，並需結合症狀與服藥。',ref:5},
{level:'基礎',q:'H抗藥、R敏感且FQ敏感的成人肺結核，建議方案為何？',o:['照用2HRZE／4HR','6個月R＋E＋Z＋levofloxacin','INH加倍劑量單藥','4個月R單藥'],a:1,e:'WHO建議H抗藥、R敏感結核使用6個月R、E、Z加levofloxacin；開始前確認FQ敏感並排除R抗藥，H可不加。',ref:11},
{level:'基礎',q:'懷孕婦女診斷藥敏感肺結核，最合適的原則？',o:['延到產後再治療','只用IGRA追蹤','選用17週rifapentine-moxifloxacin','及時開始有效治療並補充B6，與產科共同追蹤'],a:3,e:'未治療結核對母胎風險高於標準一線藥。懷孕期間不宜延後治療；17週方案與3HP缺乏懷孕資料而不使用。',ref:5},
{level:'基礎',q:'淋巴球為主、ADA偏高的肋膜積液，下列敘述何者正確？',o:['ADA高即可取代所有病原檢查','肋膜液核酸陰性就可排除結核','屬支持證據；肋膜液培養率低，必要時胸膜切片並送培養','只要IGRA陰性就排除'],a:2,e:'胸膜結核常為少菌量，肋膜液核酸及培養陽性率偏低。胸膜切片病理加培養可提高診斷率，ADA需配合臨床與鑑別診斷。',ref:4},
{level:'基礎',q:'兒童非重症結核4個月方案（2HRZ(E)／2HR）的WHO適用年齡為何？',o:['3個月至16歲','僅限12歲以上','僅限5歲以下','所有年齡含成人'],a:0,e:'WHO建議3個月至16歲、經確認非重症者可用4個月方案；成人則另循17週方案或標準6個月方案。',ref:1},
{level:'基礎',q:'病人服用rifampicin後尿液呈橘紅色，最適當的說明是？',o:['表示肝衰竭需立即停藥','藥物代謝造成的體液變色，通常無害；軟式隱形眼鏡可能被染色','表示藥物過量','表示合併尿路感染'],a:1,e:'Rifampicin可使尿液、汗、淚呈橘紅色，屬預期現象；應事先衛教，並同時說明真正需回診的肝毒性症狀。',ref:5},
{level:'基礎',q:'下列哪一種情況不宜選用3HP潛伏感染預防方案？',o:['成人、無交互作用的藥敏感接觸者','HIV陰性的年輕成人','12歲以上學生','懷孕婦女'],a:3,e:'3HP（每週H＋rifapentine共12劑）在懷孕缺乏安全資料，不建議使用；可考慮其他方案並由醫師評估時機。',ref:7},
{level:'基礎',q:'疑似肺結核住院病人在診斷釐清前，感控上應？',o:['一般病房無需特別防護','安排空氣隔離（負壓室），工作人員使用N95等級呼吸防護','只需病人戴手套','接觸隔離即可'],a:1,e:'肺／喉結核經空氣傳播；疑似時即啟動空氣隔離，解除時機及通報依疾管署現行規範。',ref:8},
{level:'基礎',q:'Xpert MTB/RIF偵測到rifampicin抗藥時，下一步最合適的是？',o:['仍照一般2HRZE開始','忽略，因快速檢測不可靠','立即進入RR路徑：加做FQ及二線藥敏，轉抗藥專責團隊','只需等6個月後再驗'],a:2,e:'快速R抗藥檢測可大幅縮短抗藥結核的有效治療時間；仍應保留培養做表現型與擴大藥敏，並同步通報。',ref:0},
{level:'基礎',q:'新診斷結核病人，下列哪項檢查屬於建議的常規基線評估？',o:['HIV檢測','腦部MRI','骨髓切片','常規冠狀動脈攝影'],a:0,e:'所有結核病人應提供HIV檢測，結果影響方案選擇、ART時機與交互作用；另做肝腎功能、CBC、血糖及EMB視力評估。',ref:5},
{level:'基礎',q:'服用rifampicin的育齡婦女使用口服避孕藥，應如何建議？',o:['不需任何調整','改用加倍劑量即可完全不受影響','停用所有避孕','rifampicin會降低荷爾蒙避孕效果，應改用或加用非荷爾蒙避孕'],a:3,e:'Rifampicin誘導肝酵素，降低口服及植入型荷爾蒙避孕效果；治療期間及停藥後約4週應採屏障或含銅IUD等方法。',ref:5},
{level:'高階',q:'HD病人60kg、H/R敏感，使用標準方案。Z與E最合理的調整原則？',o:['全部藥都改為每週一次','每日劑量減至原來四分之一即可','H/R也全部停用','Z/E保留適當單次劑量、延長至每週3次，HD日透析後給'],a:3,e:'嚴重腎功能不全時Z/E蓄積；採延長間隔以保留峰值。ATS參考Z25–35、E20–25mg/kg/次，每週3次；H/R通常維持每日。PD不能直接套HD表。',ref:5},
{level:'高階',q:'標準6個月方案下，初始空洞且第2個月培養仍陽性。最合適的處理？',o:['排查延遲反應原因，通常將H/R延續期延至7個月，總9個月','因核酸可能殘留而忽略培養','直接停藥','一律加一種FQ即可'],a:0,e:'此組合增加復發風險，需核對服藥、藥敏及吸收；此延長規則針對標準方案，不直接套用17週方案。',ref:5},
{level:'高階',q:'治療滿4個月後仍培養陽性，且曾漏藥。最重要的下一步？',o:['只重驗IGRA','疑治療失敗，重做培養藥敏並專家重訂方案及服藥支持','在失敗處方上只加一種藥','只把原藥每顆加倍'],a:1,e:'需辨識抗藥性、漏藥、吸收及交互作用；不能以加單藥方式處理失敗方案，否則可能擴大抗藥。',ref:5},
{level:'高階',q:'WHO2026更新：成人重症肺部pre-XDR-TB且具短療程資格，何者為候選？',o:['H單藥','刪除所有核心藥','BPaLC（BPaL加clofazimine）','任何人都使用4R'],a:2,e:'2026更新依嚴重度區分：非重症肺部pre-XDR可評估BPaL；重症評估BPaLC。須專責團隊確認完整資格與核心藥敏。',ref:2},
{level:'高階',q:'R抗藥、FQ敏感的合適成人肺結核，候選全口服短療程為？',o:['6H','2HRZE／4HR不需修改','4R','6個月BPaLM，經專責團隊確認'],a:3,e:'R抗藥不能沿用一般藥敏感方案；BPaLM需年齡、感染部位、懷孕、既往核心藥暴露及藥敏資格審查。',ref:3},
{level:'高階',q:'腎移植病人使用tacrolimus，現需rifampicin。最適當處理？',o:['主動評估酵素誘導交互作用，密切監測並由移植／感染團隊調整','認為兩藥絕無交互作用','未追蹤濃度直接固定加倍tacrolimus','自行永久停掉所有抗排斥藥'],a:0,e:'Rifampicin可大幅降低tacrolimus暴露，增加排斥風險；停rifampicin後也須重新評估。必要時由專家討論替代rifamycin與濃度監測。',ref:5},
{level:'高階',q:'病人曾治療TB，現在核酸陽性、培養未回、症狀與影像未釐清。應？',o:['直接斷言已復發','考慮殘留核酸與活動性疾病，核對新症狀／影像並追蹤培養','直接斷言無活動性疾病','只用IGRA判定復發'],a:1,e:'既往治療者可有殘留核酸，單一陽性結果不必然代表活菌復發；仍應警覺真正復發並完整評估。',ref:5},
{level:'高階',q:'治療中ALT為6×ULN，即使沒有肝炎症狀，應如何處理？',o:['仍未達任何處理門檻','只停B6','立即由醫師停肝毒性藥並評估病因及替代方案','等至ALT20倍再處理'],a:2,e:'無症狀ALT≥5×ULN或有症狀≥3×ULN達停藥評估門檻；需辨識其他肝炎原因並維持適當結核治療策略。',ref:5},
{level:'高階',q:'HIV病人CD4 45、有粟粒型病灶，是否可直接選成人17週方案？',o:['只要體重60kg就可以','IGRA陽性就可以','不用審查ART','不可自動選用；需評估播散／CNS、ART及交互作用'],a:3,e:'成人17週方案HIV適用條件包含CD4≥100及相容ART。此病人需要更完整的感染部位、ART時機及合併感染評估。',ref:6},
{level:'高階',q:'將高齡、糖尿病、透析及空洞各加1分，直接換算個人死亡率，是否恰當？',o:['不恰當；未驗證的自訂分數不能提供個人死亡率，應呈現風險因素與行動','恰當，任何相加皆可','只要畫成圖就有效','風險因素超過3項便可保證預後不良'],a:0,e:'風險因素可指導監測、共病處理與服藥支持，但不能在缺乏模型驗證、族群及校準資料下轉成個人存活率。',ref:5},
{level:'高階',q:'成人17週方案（2HPZM／2HPM）與標準方案相比，何者正確？',o:['以rifapentine取代rifampicin、以moxifloxacin取代ethambutol','單純把HRZE縮短為4個月','只用三週間歇給藥','不需要Z'],a:0,e:'17週方案每日H、rifapentine、moxifloxacin，前8週加Z；不是將HRZE直接縮短。須符合年齡、體重、藥敏、QT及交互作用等條件。',ref:6},
{level:'高階',q:'HIV陽性、非CNS肺結核、CD4 30，ART何時開始最合適？',o:['結核療程結束後','開始抗結核治療後2週內','6個月後','CD4回升到200後'],a:1,e:'CD4<50者早期ART可降低死亡；非CNS結核建議抗結核治療後2週內啟動。結核性腦膜炎則延後並由專家決定，以降低嚴重IRIS風險。',ref:5},
{level:'高階',q:'HIV病人開始ART後3週，淋巴結腫大、發燒復發，培養藥敏敏感且服藥規律。最可能與處理？',o:['治療失敗，立即全面換藥','停止ART','矛盾性IRIS：排除抗藥／其他感染後持續抗結核及ART，中重度可加prednisone','停抗結核藥觀察'],a:2,e:'免疫重建可使病灶短暫惡化；先排除抗藥、漏藥及其他機會感染。通常不中斷ART，中重度者可用類固醇。',ref:5},
{level:'高階',q:'BPaLM治療第8週出現貧血與腳麻，最合適處理？',o:['自行停用全部藥物','由專責團隊評估linezolid毒性，考慮減量或暫停並密切監測','加倍linezolid','改用一般2HRZE'],a:1,e:'Linezolid可致骨髓抑制、周邊及視神經病變；方案設計允許依毒性調整linezolid，但須維持有效組合並由專責團隊決定。',ref:1},
{level:'高階',q:'使用bedaquiline、moxifloxacin、clofazimine治療中，QTcF達520 ms。首要處理？',o:['停用QT延長藥物並矯正K／Mg、評估心律，由團隊重訂方案','不需處理，屬正常','改每週一次給藥即可','加用其他QT延長藥'],a:0,e:'QTcF>500 ms是停藥評估門檻；需檢查電解質、併用藥及心律，再由抗藥團隊決定替代方案。',ref:1},
{level:'高階',q:'心房顫動服用apixaban的病人需開始rifampicin，最適當處理？',o:['不需調整','apixaban劑量加倍即可','避免併用，與心臟科討論替代抗凝或改用rifabutin等方案並監測','停所有抗凝藥不再追蹤'],a:2,e:'Rifampicin強力誘導CYP3A4與P-gp，顯著降低DOAC濃度、增加栓塞風險；warfarin也需大幅調整並密切監測INR。',ref:5},
{level:'高階',q:'HIV病人ART含boosted protease inhibitor，需治療藥敏感結核，rifamycin選擇為何？',o:['照用rifampicin','改用rifabutin並調整劑量','不使用任何rifamycin','改用rifapentine每週一次'],a:1,e:'Rifampicin與boosted PI交互作用過強；rifabutin交互作用較小，可調整劑量後併用，須由感染專科確認。',ref:5},
{level:'高階',q:'藥物性肝炎停藥後ALT降至<2×ULN，重新給藥的建議順序？',o:['四藥同時恢復全量','先Z再H','永久不再使用任何一線藥','先R（可併E），再H；Z最後或不再使用'],a:3,e:'R肝毒性相對較低且最重要，先恢復；之後加H並監測。若再次肝炎則停用最後加入的藥；Z常被省略並延長療程。',ref:5},
{level:'高階',q:'MDR／RR-TB病人的家戶接觸者，排除活動性疾病後，WHO建議的預防治療為何？',o:['3HP','4R','依接觸源藥敏，6個月levofloxacin並由專家評估','不需任何預防'],a:2,e:'接觸源R抗藥時，rifamycin類方案無效；FQ敏感者可評估6個月levofloxacin，並長期追蹤症狀。',ref:7},
{level:'高階',q:'HIV陰性頸部淋巴結結核，治療第2個月淋巴結變大，服藥規律、藥敏敏感。最可能與處理？',o:['矛盾反應：排除抗藥及其他診斷後通常繼續原方案，必要時抽吸','立即判定治療失敗','停藥觀察','改為R抗藥方案'],a:0,e:'淋巴結結核治療中矛盾性腫大常見，不代表失敗；應確認服藥與藥敏，波動性病灶可抽吸或引流。',ref:5}
];
const mapData=[
 ['1｜辨識與感控',[
 ['臨床線索',['持續咳嗽、發燒、夜間盜汗、體重減輕、咳血；高齡或免疫抑制症狀可能不典型。','接觸史、既往TB、居住及照護場域、免疫治療、糖尿病與腎病一併評估。']],
 ['急症優先',['呼吸衰竭、休克、大量咳血、新神經缺損：先急診／住院及器官支持。','疑似肺／喉結核啟動空氣隔離與院內感控；通報及解除隔離依台灣現行規範。']]
 ]],
 ['2｜逐步建立診斷',[
 ['影像',['先胸部X光，必要時CT；空洞、粟粒型或上肺病灶可支持但不能單獨確診。','肺外病灶也應評估同時存在肺部結核。']],
 ['取得檢體',['肺部：痰塗片、MTB核酸、培養、藥敏並行；無痰考慮誘導痰／支氣管鏡。','肺外：依部位送組織或體液，病理與微生物分開妥善送驗；培養檢體不可全部固定於福馬林。']],
 ['診斷定位',['MTB核酸或培養支持病原學證實，仍需核對檢體及病史。','檢體陰性但臨床高度支持：醫師可作臨床診斷並追蹤反應。','疑似尚未證實：安排下一步採檢，重症者採檢後評估經驗性治療。']]
 ]],
 ['3｜檢驗陷阱與鑑別',[
 ['塗片、核酸、培養',['AFB陽性≠必定MTB，需鑑別NTM；塗片陰性不能排除。','核酸陰性不能排除少菌量／肺外疾病；培養保留菌株以供藥敏。','曾治療者核酸可殘留：用新症狀、影像與培養判斷活動性，不能單靠核酸宣告復發。']],
 ['感染檢測與病理',['IGRA／TST不能區分活動性與潛伏感染，也不作治癒檢測。','乾酪性壞死、肉芽腫、ADA只是支持證據；需鑑別NTM、真菌、腫瘤及其他炎症。','免疫抑制者感染檢測陰性或無法判讀，不能據此排除活動性結核。']]
 ]],
 ['4｜藥敏與抗藥分類',[
 ['第一線與第二線',['所有可取得菌株進行適當藥敏，快速R檢測協助初始決策。','R抗藥即進入RR路徑；MDR指至少H及R同時抗藥。','pre-XDR為MDR／RR再合併FQ抗藥；需核心二線藥敏與專責團隊。']],
 ['資料未齊',['未知≠敏感；報告未回時顯示推定初始治療，持續修正。','H抗藥、R敏感：評估6個月R＋E＋Z＋levofloxacin，確認FQ敏感及各藥可用。']]
 ]],
 ['5｜藥敏感治療模式',[
 ['標準療程',['2HRZE／4HR：前2月四藥，後4月H/R；每日與都治支持。','H/R敏感且無法使用Z或Z抗藥時，通常需9個月方案。','初始空洞＋第2月培養仍陽性：標準方案通常總9月，並查延遲反應原因。']],
 ['成人17週候選',['8週H＋rifapentine＋Z＋moxifloxacin；再9週H＋rifapentine＋moxifloxacin，共119劑。','≥12歲、≥40kg、合適肺結核；核對藥敏、QT、懷孕哺乳與交互作用。','腎病、近期相關用藥或其他特殊條件需專家諮詢；本工具採保守篩選。']],
 ['兒童非重症',['3個月至16歲符合非重症者可評估2HRZ(E)／2HR。','少菌量、非空洞及無粟粒型，或符合特定淋巴結／非複雜胸膜病灶定義；兒科確認。','兒童劑量不可直接用成人上限或成人mg/kg替代。']]
 ]],
 ['6｜抗藥性治療模式',[
 ['WHO2026分層',['合適MDR／RR：6個月BPaLM候選。','非重症肺部pre-XDR：BPaL候選；重症：BPaLC候選。','不能使用上述方案時，依藥敏與資格評估其他全口服短／長療程。']],
 ['核心安全審查',['確認年齡、妊娠哺乳、肺外部位、核心藥既往暴露、各藥敏感性與可用性。','Bedaquiline／moxifloxacin／clofazimine等注意QT；linezolid注意CBC、視／周邊神經毒性。','失敗方案不可只加一種藥；二線劑量及調整由專責團隊確認。']]
 ]],
 ['7｜特殊族群與部位',[
 ['腎病與透析',['CrCl用於劑量調整，不直接與標準化eGFR等同；必要時確認體表面積與實測功能。','H/R通常維持每日；CrCl<30或HD，Z25–35及E20–25mg/kg/次每週3次（ATS）。','HD日透析後給藥；PD資料較少、不可直接套HD；必要時TDM。']],
 ['免疫抑制與移植',['Rifampicin強交互作用：tacrolimus、cyclosporine、抗凝劑、ART等需主動處理。','開始與停止rifamycin時均應重新評估共用藥濃度與效果。','HIV需整合CD4、ART時機及部位，CNS感染另行考量IRIS。']],
 ['中樞神經與骨關節',['成人TB腦膜炎通常9–12月，並合併類固醇於6–8週漸減。','骨關節／脊椎視神經壓迫、病灶與反應決定療程及手術評估。','孕婦立即適當治療；17週RPT/MOX及3HP不自動套用，交由專家。']]
 ]],
 ['8｜潛伏結核感染',[
 ['診斷前提',['感染檢測陽性＋完成活動性結核排除；有症狀或病灶先釐清。','接觸源藥敏、接觸窗口期、免疫狀態與治療適應症一併審查。']],
 ['預防方案',['3HP：每週H＋rifapentine，共12劑；4R：每日R，共4月。','3HR：每日H＋R，共3月；6H／9H為替代。','懷孕、交互作用、肝病與HIV需方案審查；抗藥接觸者另循專門預防指引。']]
 ]],
 ['9｜毒性與追蹤',[
 ['基線與定期',['基線體重、CBC、肝腎功能、HIV、EMB視力／色覺；依藥物安排ECG與電解質。','每月症狀、體重、服藥支持與副作用；肝功能頻率按風險及症狀。','肺結核定期痰培養；第2月轉陰重要，核酸不替代培養判定活菌。']],
 ['立即處理',['ALT有症狀≥3×ULN或無症狀≥5×ULN：停肝毒性藥並醫師評估。','視力或色覺改變：立即停EMB及眼科評估。','不可自行停掉全部療程後不追蹤，需維持有效替代組合及計畫。']]
 ]],
 ['10｜預後與治療結束',[
 ['不利因素',['高齡、嚴重腎病、糖尿病、HIV／免疫抑制、營養不良與病灶範圍。','空洞、培養延遲轉陰、抗藥、漏藥／中斷：連結復發與失敗風險評估。','此工具不自行加總為死亡率；未知資料不能當低風險。']],
 ['動態反應與後續',['第4月後仍培養陽性：疑失敗，採新檢體與重做藥敏。','完成足量療程後評估殘餘肺功能障礙及復發症狀，安排個別追蹤。','確保營養、共病控制、都治與可近性；有效完整治療下多數藥敏感結核可治癒。']]
 ]],
 ['11｜兒童與青少年',[
 ['診斷特點',['症狀常不典型：生長遲滯、持續發燒、活動力下降；接觸史是重要線索。','檢體：誘導痰、胃液、鼻咽吸取；WHO建議兒童可用糞便檢體做Xpert Ultra。','臨床診斷比例高；陰性檢驗不能排除，需兒科整合判斷。']],
 ['治療選擇',['3個月至16歲非重症：4個月2HRZ(E)／2HR；重症或不符定義：6個月標準方案。','兒童結核性腦膜炎另有專門方案（如6個月強化方案），須兒科感染專家決定。','劑量依體重帶與兒童劑型；不可用成人上限或成人表推算。']],
 ['預防與接觸者',['5歲以下接觸者即使感染檢測陰性，排除活動性疾病後常需評估預防治療。','R抗藥接觸者另循抗藥接觸預防指引。']]
 ]],
 ['12｜懷孕與哺乳',[
 ['治療原則',['懷孕不延後活動性結核治療；未治療的母胎風險高於標準一線藥。','含INH者補充B6；與產科共同監測肝功能（產後早期肝毒性風險增加）。','17週rifapentine-moxifloxacin及3HP缺乏懷孕資料，不使用。']],
 ['哺乳與新生兒',['一線藥可哺乳，乳汁藥量不足以治療或預防嬰兒；授乳嬰兒補B6評估。','新生兒需評估先天或產後感染，母親具傳染性時依規範安排預防及隔離。']],
 ['避孕',['Rifampicin降低荷爾蒙避孕效果；治療期間及停藥後約4週改用非荷爾蒙方法。']]
 ]],
 ['13｜HIV與IRIS',[
 ['ART時機',['所有結核病人提供HIV檢測。','非CNS結核：CD4<50於抗結核治療後2週內開始ART；其餘通常8週內。','結核性腦膜炎：ART延後並由專家決定，以減少嚴重IRIS。']],
 ['交互作用',['Rifampicin與boosted PI不宜併用，可改rifabutin並調整劑量。','Dolutegravir併用rifampicin需提高頻次（每日兩次）；efavirenz多可照常。','17週方案HIV條件：CD4≥100且ART相容。']],
 ['IRIS',['ART後數週病灶短暫惡化、發燒、淋巴結腫大。','先排除抗藥、漏藥及其他感染；通常持續抗結核及ART，中重度可加prednisone。']]
 ]],
 ['14｜藥物交互作用',[
 ['Rifampicin誘導',['強力誘導CYP3A4、P-gp等：降低DOAC、warfarin、tacrolimus、cyclosporine、azole、methadone、類固醇、荷爾蒙避孕藥等濃度。','DOAC原則避免併用；warfarin需密切監測INR；免疫抑制劑需血中濃度監測。','停用rifampicin後誘導作用約2週逐漸消退，併用藥劑量須再下修。']],
 ['其他藥物',['INH抑制phenytoin、carbamazepine代謝，可能增加毒性。','Rifabutin誘導作用較弱，用於需保留PI或免疫抑制劑者。','FQ、bedaquiline、clofazimine：注意QT延長藥物與電解質；FQ避免與含鈣、鎂、鐵製劑同時服用。']]
 ]],
 ['15｜不良反應處置',[
 ['肝毒性',['停藥門檻：有症狀ALT≥3×ULN或無症狀≥5×ULN；排除病毒性、酒精及其他藥物。','ALT<2×ULN後依序重新給藥：R（±E）→H；Z最後或不再使用並延長療程。','重症者停藥期間可暫用較少肝毒性藥物（如E、FQ、aminoglycoside）由專家決定。']],
 ['其他常見反應',['周邊神經病變：INH相關，高風險者B6 25–50 mg/day預防。','Z：高尿酸、關節痛；痛風發作需評估。','皮疹：輕度可對症；伴發燒、黏膜或肝功能異常即停所有藥，評估嚴重皮膚反應。','EMB：視力及紅綠色覺異常立即停藥；腎功能差者風險增加。']],
 ['二線藥',['Linezolid：骨髓抑制、周邊及視神經病變，依毒性減量或暫停。','Bedaquiline／moxifloxacin／clofazimine：QTcF>500 ms停藥評估。','Clofazimine：皮膚色素沉著，需事先衛教。']]
 ]]
];
let qi=0;const QN=questions.length,answers=Array(QN).fill(null),locked=Array(QN).fill(false);
const lvlScore=l=>{const ix=questions.map((q,i)=>q.level===l?i:-1).filter(i=>i>=0);return `${ix.filter(i=>locked[i]&&answers[i]===questions[i].a).length}／${ix.length}`};
function renderQuiz(){const q=questions[qi];const done=locked.filter(Boolean).length,correct=answers.filter((a,i)=>locked[i]&&a===questions[i].a).length;
 document.querySelector('#quiz-body').innerHTML=`<label class="quiz-jump">跳到題目 <select id="qjump">${questions.map((x,i)=>`<option value="${i}" ${i===qi?'selected':''}>${i+1}. ${x.level}${locked[i]?(answers[i]===x.a?' ✓':' ✗'):''}</option>`).join('')}</select></label><div class="quiz-progress" aria-hidden="true"><span style="width:${done/QN*100}%"></span></div><p class="quiz-meta">第${qi+1}／${QN}題 · ${q.level}　｜　已作答${done}題 · 答對${correct}題</p><h3>${esc(q.q)}</h3><fieldset><legend class="sr-only">選擇答案</legend>${q.o.map((o,i)=>`<label class="answer ${locked[qi]&&i===q.a?'correct':''} ${locked[qi]&&answers[qi]===i&&i!==q.a?'incorrect':''}"><input type="radio" name="quizanswer" value="${i}" ${answers[qi]===i?'checked':''} ${locked[qi]?'disabled':''}><span>${String.fromCharCode(65+i)}. ${esc(o)}</span></label>`).join('')}</fieldset>${locked[qi]?`<div class="explain"><b>${answers[qi]===q.a?'答對了':'本題答錯'} · 正確答案${String.fromCharCode(65+q.a)}</b><p>${esc(q.e)}</p><a href="${refs[q.ref][1]}" target="_blank" rel="noopener">依據：${esc(refs[q.ref][0])} ↗</a></div>`:''}<div class="pager"><button id="qprev" ${qi===0?'disabled':''}>← 前題</button><button id="qcheck" class="primary" ${locked[qi]?'disabled':''}>確認答案</button><button id="qnext" ${qi===QN-1?'disabled':''}>後題 →</button></div>${done===QN?`<p class="result">完成${QN}題：${correct}／${QN}。基礎${lvlScore('基礎')}；高階${lvlScore('高階')}。可切換題目複習解析；不作為臨床能力認證。</p>`:''}`;
 document.querySelectorAll('[name="quizanswer"]').forEach(el=>el.onchange=()=>{answers[qi]=Number(el.value)});
 document.querySelector('#qjump').onchange=e=>{qi=Number(e.target.value);renderQuiz()};document.querySelector('#qprev').onclick=()=>{qi--;renderQuiz()};document.querySelector('#qnext').onclick=()=>{qi++;renderQuiz()};
 document.querySelector('#qcheck').onclick=()=>{if(answers[qi]===null){document.querySelector('#quiz-feedback').textContent='請先選擇一個答案。';return;}document.querySelector('#quiz-feedback').textContent='';locked[qi]=true;renderQuiz();document.querySelector('#quiz-body .explain')?.setAttribute('tabindex','-1');document.querySelector('#quiz-body .explain')?.focus()};
}

const mapGroups=[['A｜診斷與辨識','步驟1–2：警訊、採檢、檢驗判讀','t1',[0,1,2]],['B｜藥敏與治療模式','步驟3：抗藥分類、藥敏感與抗藥方案','t2',[3,4,5]],['C｜特殊族群與交互作用','步驟1、3：腎病、兒童、懷孕、HIV、併用藥','t3',[6,10,11,12,13]],['D｜預防、毒性與追蹤','步驟4：LTBI、不良反應、預後','t4',[7,8,14,9]]];
const branchHTML=([title,branches])=>`<details class="mind-branch"><summary>${esc(title.replace(/^\d+｜/,''))}</summary><div>${branches.map(([sub,leaves])=>`<details class="mind-sub"><summary>${esc(sub)}</summary>${list(leaves)}</details>`).join('')}</div></details>`;
document.querySelector('#mindmap').innerHTML=mapGroups.map(([g,sub,cls,ix])=>`<section class="map-group ${cls}"><h3>${g}</h3><p>${sub}</p>${ix.map(i=>branchHTML(mapData[i])).join('')}</section>`).join('');
document.querySelector('#quiz-restart').onclick=()=>{answers.fill(null);locked.fill(false);qi=0;renderQuiz();document.querySelector('#quiz-feedback').textContent='已重新開始。'};
document.querySelector('#map-expand').onclick=()=>document.querySelectorAll('#mindmap details').forEach(d=>d.open=true);
document.querySelector('#map-search').oninput=e=>{const q=e.target.value.trim().toLowerCase();let n=0;document.querySelectorAll('#mindmap .mind-branch').forEach(b=>{let hit=false;b.querySelectorAll('.mind-sub').forEach(sb=>{let subHit=false;sb.querySelectorAll('li').forEach(li=>{const m=!q||li.textContent.toLowerCase().includes(q)||sb.querySelector('summary').textContent.toLowerCase().includes(q)||b.querySelector('summary').textContent.toLowerCase().includes(q);li.hidden=!m;li.classList.toggle('hit',!!q&&m);if(m){subHit=true;if(q)n++}});sb.hidden=!subHit;sb.open=!!q&&subHit;hit=hit||subHit});b.hidden=!hit;b.open=!!q&&hit});document.querySelectorAll('#mindmap .map-group').forEach(g=>g.hidden=!g.querySelector('.mind-branch:not([hidden])'));document.querySelector('#map-count').textContent=q?(n?`找到${n}項相關內容`:'沒有符合的內容'):''};
document.querySelector('#map-collapse').onclick=()=>document.querySelectorAll('#mindmap details').forEach(d=>d.open=false);
if(!document.querySelector('#view-quiz').hidden)renderQuiz();
