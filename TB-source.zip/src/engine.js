/* TB Clinical Navigator — deterministic decision support, reviewed 2026-11-10. */
(function(root){
const isYes=(s,k)=>s[k]==='yes';
const num=(s,k)=>s[k]!==''&&s[k]!=null&&Number.isFinite(Number(s[k]))?Number(s[k]):null;
function assess(s){
 const age=num(s,'age'),w=num(s,'weight'),cr=num(s,'crcl');
 const urgent=['resp','shock','hemoptysis','neuro'].filter(k=>isYes(s,k));
 const symptoms=['cough','fever','loss','night'].some(k=>isYes(s,k));
 const image=['suggestive','cavity','miliary'].includes(s.image);
 const positive=s.naat==='positive'||s.culture==='positive';
 const suspect=symptoms||image||s.smear==='positive'||(isYes(s,'contact')&&!isYes(s,'excluded'))||isYes(s,'clinical');
 const conflicts=[];
 if(isYes(s,'excluded')&&(positive||image||symptoms||isYes(s,'clinical')))conflicts.push('「已排除活動性結核」與目前症狀／影像／病原結果衝突；先重新確認，不可進入潛伏感染單藥治療。');
 if(s.rif==='resistant'&&s.naat==='negative'&&s.culture==='negative')conflicts.push('R 抗藥結果與兩項陰性病原結果不一致，請核對檢體、日期及檢驗方法。');
 let dx='資料不足，尚待評估',code='incomplete',detail='先完成症狀、影像與病原檢驗，未填資料不等於正常。';
 if(positive){code='confirmed';dx='病原學支持活動性結核';detail='MTB 核酸或培養陽性；須結合病史及檢體部位，完成藥敏。';if(isYes(s,'past')&&s.naat==='positive'&&s.culture!=='positive'){code='review';dx='MTB 核酸陽性，需確認是否活動性';detail='曾治療者可能殘留核酸；評估新症狀、影像變化與培養，不能單靠核酸判定復發。';}}
 else if(isYes(s,'clinical')){code='clinical';dx='臨床診斷活動性結核';detail='由醫師綜合證據及排除替代診斷後判定；檢體陰性不排除，需持續評估治療反應。';}
 else if(suspect){code='suspected';dx='疑似活動性結核，須進一步採檢';detail='陰性塗片或核酸不能完全排除；若重症／高度懷疑，採檢後由醫師決定經驗性治療。';}
 else if(isYes(s,'excluded')&&s.igra==='positive'){code='ltbi';dx='符合潛伏結核感染評估路徑';detail='感染檢測陽性且已完成活動性疾病排除；依接觸源藥敏與個別條件選擇預防療程。';}
 else if(isYes(s,'excluded')){code='noactive';dx='目前評估未見活動性結核';detail='感染檢測陰性仍須考量免疫抑制與接觸窗口期；有新症狀時重新評估。';}
 if(conflicts.length){code='conflict';dx='資料衝突：請先重新評估';detail=conflicts.join(' ');}
 const next=[];
 if(s.naat==='unknown')next.push('取得病灶檢體，安排 MTB 核酸及快速 R 抗藥檢測。');
 if(s.culture!=='positive')next.push('取得足量檢體送分枝桿菌培養、菌種鑑定及藥敏；若已送驗則追蹤結果。');
 if(s.smear==='positive'&&s.naat==='negative')next.push('AFB 陽性／MTB 核酸陰性：考慮 NTM、檢體抑制或技術因素，複驗並等待菌種。');
 if(s.site!=='pulmonary')next.push('肺外病灶：組織／體液送培養、適用核酸及病理；陰性不能排除。');
 if(s.image==='unknown')next.push('完成胸部 X 光，必要時 CT；肺外結核也應評估是否合併肺部感染。');
 if(s.rif==='unknown'||s.inh==='unknown')next.push('補足 R／H 藥敏；若 R 抗藥，再加速 FQ 與核心二線藥敏。');
 const renal=isYes(s,'hd')||isYes(s,'pd')||(cr!==null&&cr<30);
 const active=['confirmed','clinical'].includes(code);
 let treatment={title:'先完成診斷及藥敏評估',kind:'pending',duration:'尚未決定',lines:['不可將 IGRA 陽性直接當作活動性結核，也不可將陰性檢驗直接當成排除。'],short:false};
 let shortReasons=[];
 if(active){
  if(s.rif==='resistant'){
   let elig=age!==null&&age>=14&&s.preg==='no'&&s.breast==='no'&&!['cns','bone'].includes(s.site)&&s.core==='no';
   treatment={kind:'dr',duration:'符合資格者約6個月；仍須專責團隊確認',title:'R 抗藥結核：轉抗藥結核專責團隊',short:false,lines:[]};
   if(s.site!=='pulmonary')treatment.lines.push('肺外R抗藥結核：本工具不自動指定肺部短療程；依感染部位與核心藥敏由專責團隊個別化。');
   else if(s.fq==='sensitive')treatment.lines.push('候選方案：BPaLM（bedaquiline＋pretomanid＋linezolid＋moxifloxacin）。');
   else if(s.fq==='resistant')treatment.lines.push(s.severity==='severe'?'WHO 2026：重症肺部 pre-XDR 候選 BPaLC（加 clofazimine）。':s.severity==='nonsevere'?'WHO 2026：非重症肺部 pre-XDR 候選 BPaL。':'FQ 抗藥：先判定重症程度，再由團隊選擇 BPaL／BPaLC 或其他方案。');
   else treatment.lines.push('FQ 藥敏未明：立即補驗；由專責團隊決定初始全口服方案，不能自動刪除 moxifloxacin。');
   if(!elig)treatment.lines.push('短療程資格尚未完整確認或存在限制：年齡、懷孕／哺乳、感染部位、核心藥物既往暴露及藥敏均須審查。');
   treatment.lines.push('本工具不自動開立二線藥劑量；須評估核心藥敏、QTc、血球、肝功能、周邊／視神經毒性及交互作用。');
  }else if(s.inh==='resistant'&&s.rif==='sensitive'){
   treatment={kind:'hr',title:'INH 抗藥、R 敏感結核：專家確認處方',duration:'通常6個月',short:false,lines:['可評估 R＋E＋Z＋levofloxacin 的6個月方案，須確認 FQ 藥敏、Z／E 可用及感染部位。','腎功能不全時 levofloxacin、Z、E 需調整；不可照用一般2HRZE／4HR。']};
  }else if(s.inh==='resistant'||s.pza==='resistant'||s.fq==='resistant'){
   treatment={kind:'other',title:'有個別藥物抗藥：需調整方案',duration:'依藥敏與部位決定',short:false,lines:['先釐清完整藥敏，交由結核專家制定有效多藥組合。','若僅 Z 抗藥／不可用且 H、R 確定敏感，常需總療程9個月。']};
  }else{
   treatment={kind:'ds',title:s.rif==='sensitive'&&s.inh==='sensitive'?'藥敏感結核：標準6個月療程':'推定藥敏感結核：初始四藥，等待藥敏',duration:'2HRZE／4HR，共6個月',short:false,lines:['前2個月 H＋R＋Z＋E；後4個月 H＋R。藥敏確定後由醫師決定 E 停用時點。','採每日給藥及都治／視訊都治支持；腎功能相關 Z／E 給藥間隔另見劑量表。']};
   if(s.site==='cns'){treatment.duration='成人通常9–12個月';treatment.lines.push('結核性腦膜炎：專科住院評估，合併 dexamethasone 或 prednisolone，通常於6–8週逐漸減量。');}
   else if(s.site==='bone'){treatment.duration='常需6–9個月，複雜脊椎病灶可能更久';treatment.lines.push('骨關節／脊椎結核：依病灶、神經壓迫、手術及治療反應個別化。');}
   else if(s.site!=='pulmonary'){treatment.duration='多數肺外部位6–9個月';treatment.lines.push('成人肺外結核不自動套用 rifapentine 四個月方案。');}
   if(s.pzaUse==='no'){treatment.duration='H／R敏感者通常總療程9個月';treatment.lines.push('無法使用 Z：標準縮短療程條件不成立，需重訂延長方案。');}
   if(s.image==='cavity'&&s.month2==='positive'&&s.site==='pulmonary'){treatment.duration='標準六個月方案通常延長為9個月';treatment.lines.push('起始空洞＋治療滿2個月培養仍陽性：H／R 延續期通常延至7個月；同時排查服藥、藥敏及吸收。');}
   const req=[['需確認無急症警訊',['resp','shock','hemoptysis','neuro'].every(k=>s[k]==='no')],['年齡需≥12歲',age!==null&&age>=12],['體重需≥40 kg',w!==null&&w>=40],['限一般肺結核',s.site==='pulmonary'],['H／R／Z／FQ均需確認敏感',s.inh==='sensitive'&&s.rif==='sensitive'&&s.pza==='sensitive'&&s.fq==='sensitive'],['需確認無懷孕或哺乳',s.preg==='no'&&s.breast==='no'],['需確認無QT延長／相關併用藥',s.qt==='no'],['需完成交互作用審查',s.ddi==='no'],['需確認無嚴重肝病',s.liver==='no'],['腎功能及透析狀態需完整；CKD須先專家諮詢',cr!==null&&cr>=60&&s.hd==='no'&&s.pd==='no'],['需確認無近期結核／FQ暴露或既往治療疑慮',s.prior==='no'&&s.past==='no'],['HIV狀態與ART相容性需確認',s.hiv==='no'||(s.hiv==='yes'&&num(s,'cd4')>=100&&s.art==='yes')],['需可使用Z',s.pzaUse==='yes'],['第2個月仍陽性者先釐清反應',s.month2!=='positive']];
   shortReasons=req.filter(x=>!x[1]).map(x=>x[0]);
   if(!shortReasons.length){treatment.short=true;treatment.lines.push('另符合四個月候選篩選：2HPZM／2HPM（8週＋9週，共119劑）。可與病人討論，最終由醫師確認；不是直接縮短HRZE。');}
   if(age!==null&&age>=0.25&&age<=16&&s.child==='yes'&&s.rif==='sensitive'&&s.inh==='sensitive'&&s.pzaUse==='yes'&&s.image!=='cavity'&&s.image!=='miliary'&&!['cns','bone'].includes(s.site)&&s.severity==='nonsevere'&&s.month2!=='positive'){
    treatment.lines.push('另可評估兒童非重症4個月方案：2HRZ(E)／2HR；由兒科確認非重症定義及兒童劑量。成人劑量表不適用。');
   }
  }
 }else if(code==='ltbi'){
  treatment={kind:'ltbi',title:'潛伏感染：先核對感染源藥敏，再選預防治療',duration:'3HP／4R／3HR；6H或9H為替代',short:false,lines:['一般藥敏感感染：3HP＝每週H＋rifapentine共12劑；4R＝每日R共4個月；3HR＝每日H＋R共3個月。','若懷孕、哺乳、肝病、HIV或交互作用未釐清，不自動指定單一方案。3HP不適用孕婦。','接觸抗藥結核者須另循抗藥接觸者預防指引；本工具不自動套用上述處方。']};
 }
 const risk=[],actions=[];
 if(urgent.length){risk.push('有急症警訊');actions.push('先急診／住院穩定病況，疑似肺或喉結核啟動空氣隔離與感控。');}
 if(age!==null&&age>=65)risk.push('高齡：耐受性及不良結局風險增加');
 if(renal)risk.push('嚴重腎功能不全／透析：毒性與治療監測需求增加');
 if(isYes(s,'dm'))risk.push('糖尿病：治療反應與復發風險需密切追蹤');
 if(isYes(s,'immune')||s.hiv==='yes')risk.push('免疫抑制／HIV：須整合感染及免疫治療');
 if(isYes(s,'malnutrition'))risk.push('營養不良：需營養支持與體重追蹤');
 if(s.image==='cavity'||s.image==='miliary')risk.push(s.image==='cavity'?'空洞病灶：復發風險因素':'粟粒型病灶：評估播散及器官受累');
 if(s.rif==='resistant'||s.inh==='resistant'||s.fq==='resistant')risk.push('抗藥性：治療選擇及毒性負擔較高');
 if(s.adherence==='poor')risk.push('漏藥／中斷：失敗、復發及新增抗藥風險');
 if(s.month2==='positive'){risk.push('第2個月培養仍陽性：反應延遲，需查明原因');actions.push('核對服藥、藥敏、吸收及交互作用；必要時藥物濃度監測。');}
 if(s.month4==='positive'){risk.push('第4個月後培養仍陽性：疑治療失敗');actions.push('採新檢體培養與重做藥敏，立即結核專家評估；不可只在失敗處方上加一種藥。');}
 const alt=num(s,'alt');
 const liverAlert=alt!==null&&(alt>=5||(alt>=3&&isYes(s,'hepatitis')));
 if(liverAlert)actions.unshift('ALT達停藥警戒：有症狀≥3×ULN或無症狀≥5×ULN，立即由醫師停肝毒性藥並評估替代方案。');
 if(isYes(s,'vision'))actions.unshift('出現視力／色覺改變：立即停EMB，緊急眼科與結核團隊評估。');
 if(s.month2==='negative')actions.push('第2個月培養轉陰為有利反應，但仍需完成足量療程；不能提早自行停藥。');
 const dose=[];
 if(active&&treatment.kind==='ds'&&age!==null&&age>=18&&w!==null&&w>=30&&w<=90&&cr!==null&&['yes','no'].includes(s.hd)&&['yes','no'].includes(s.pd)){
  dose.push(['H · Isoniazid',`${Math.min(300,Math.round(w*5))} mg，每日（5 mg/kg，上限300 mg）`,'肝毒性、周邊神經；高風險者B6 25–50 mg/day']);
  dose.push(['R · Rifampicin',`${Math.min(600,Math.round(w*10))} mg，每日（10 mg/kg，依美國一般標準上限600 mg）`,'核對交互作用、肝功能；製劑需藥師確認']);
  if(s.pzaUse!=='no')dose.push(['Z · Pyrazinamide',isYes(s,'pd')?'PD需個別化劑量及必要時TDM；不直接套用HD表':renal?`${Math.round(w*25)}–${Math.round(w*35)} mg／次，每週3次`:`${Math.round(w*20)}–${Math.round(w*25)} mg，每日（20–25 mg/kg）`,'肝毒性、高尿酸；實際錠數依體重帶確認']);
  dose.push(['E · Ethambutol',isYes(s,'pd')?'PD需個別化劑量及必要時TDM；不直接套用HD表':renal?`${Math.round(w*20)}–${Math.round(w*25)} mg／次，每週3次（ATS）`:`${Math.round(w*15)}–${Math.round(w*20)} mg，每日（15–20 mg/kg）`,'基線與每月視力／色覺；異常即停藥評估']);
 }
 let missing=[];
 for(const [k,label] of [['age','年齡'],['weight','體重'],['crcl','CrCl'],['site','感染部位'],['hiv','HIV狀態'],['preg','懷孕狀態'],['qt','QT風險'],['ddi','交互作用']])if(s[k]===''||s[k]==='unknown'||s[k]==null)missing.push(label);
 return {dx,code,detail,urgent,conflicts,next,treatment,shortReasons,renal,dose,risk,actions,liverAlert,missing,active};
}
root.TB={assess};if(typeof module!=='undefined')module.exports={assess};
})(typeof window!=='undefined'?window:globalThis);
