from pathlib import Path
root=Path(__file__).resolve().parent
h=(root/'src/template.html').read_text()
for key,name in [('ENGINE','engine.js'),('UI','ui.js'),('LEARNING','learning.js')]:
    h=h.replace('/*'+key+'*/',(root/'src'/name).read_text())
(root/'dist').mkdir(exist_ok=True)
(root/'dist/index.html').write_text(h)
(root/'index.html').write_text(h)
print('Built self-contained index.html:',len(h.encode()),'bytes')
